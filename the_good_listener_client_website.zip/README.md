# The Good Listener — Client Website

A responsive, vintage-inspired event website for **The Good Listener Open Mic Show, Sujangarh**.

## Files
- `index.html` — all website content
- `styles.css` — responsive red / cream / mustard / navy visual theme
- `app.js` — mobile menu and registration form logic
- `config.js` — public Supabase project URL and anon/publishable key configuration
- `supabase/setup.sql` — database table and safe insert-only policy
- `assets/logo.png` — optional logo image (replace with approved logo)

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a browser. Some browsers restrict local requests; a local server is better.
3. In VS Code, install/use Live Server and choose **Open with Live Server**.

The site is intentionally in **preview mode** until Supabase is configured. In preview mode it does not send or store registration details.

## Enable real registration storage with Supabase
1. Create a project at https://supabase.com/ and keep the project owner login private.
2. Open **SQL Editor**, paste and run `supabase/setup.sql`.
3. Go to Project Settings / API (or Connect) and copy the **Project URL** and **publishable/anon key**.
4. Paste these into `config.js`:
   ```js
   window.TGL_CONFIG = {
     supabaseUrl: "https://YOUR-PROJECT.supabase.co",
     supabaseAnonKey: "YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY"
   };
   ```
5. Save, reload the site and submit a test registration using your own test details.
6. In Supabase Table Editor, open `registrations` and confirm the test row appears. Delete test data when done.
7. Before launch, test required fields, invalid email/phone, mobile layout, and a failed-network submission.

## Security notes
- The browser-visible anon/publishable key is expected to be public. Row Level Security (RLS) is enabled and the provided policy only permits insert requests that include consent and `status = 'pending'`.
- Never put a `service_role` or secret key in `config.js`, HTML, JavaScript, GitHub, or this ZIP.
- Public visitors cannot read registrations through the policy in this setup. Review registrations through the Supabase owner dashboard. A separate admin dashboard requires authenticated admin roles and server-side/RLS policies; it is not included in this starter.
- Add rate limiting / CAPTCHA and spam monitoring before promoting the form widely. Public forms can receive spam.
- Add a privacy notice that matches the event organiser's actual data handling and retention practices before launch.
- This form records registration requests, not confirmed performance slots. Confirm performers manually.

## Publish
For a static website, upload these files to a static host such as GitHub Pages or Netlify. Keep the folder structure intact. Registration storage requires a configured Supabase project. Supabase and domain/hosting fees (if any) are separate from the website files.

## Client handover checklist
- [ ] Replace `assets/logo.png` with the approved original logo (transparent PNG recommended).
- [ ] Confirm event date, venue, registration rules and slot capacity before adding them publicly.
- [ ] Configure Supabase and test a real registration.
- [ ] Transfer hosting/domain ownership and Supabase project ownership to the client.
- [ ] Give the client this ZIP and this README; do not share your personal account password.
