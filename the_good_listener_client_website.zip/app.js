const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle?.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
navLinks?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('registrationForm');
const statusEl = document.getElementById('formStatus');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  statusEl.className = 'form-status';
  const cfg = window.TGL_CONFIG || {};
  const data = Object.fromEntries(new FormData(form).entries());
  data.created_at = new Date().toISOString();
  data.status = 'pending';
  if (!document.getElementById('consent').checked) {
    statusEl.textContent = 'Please agree to be contacted before submitting.';
    statusEl.classList.add('error'); return;
  }
  const submit = form.querySelector('button[type="submit"]');
  submit.disabled = true; submit.textContent = 'SENDING…';
  try {
    if (cfg.supabaseUrl && cfg.supabaseAnonKey) {
      const endpoint = cfg.supabaseUrl.replace(/\/$/, '') + '/rest/v1/registrations';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': cfg.supabaseAnonKey,
          'Authorization': 'Bearer ' + cfg.supabaseAnonKey,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          full_name: data.full_name,
          phone: data.phone,
          email: data.email || null,
          act_type: data.act_type,
          act_title: data.act_title || null,
          message: data.message || null,
          consent: true,
          status: 'pending'
        })
      });
      if (!response.ok) throw new Error('Database rejected the request (' + response.status + '). Check Supabase setup and table policies.');
      form.reset();
      statusEl.textContent = 'Registration request received! The team will contact you to confirm your slot.';
      statusEl.classList.add('success');
    } else {
      // Safe preview mode: no personal data is sent or stored. Configure Supabase to enable real registrations.
      statusEl.textContent = 'Preview mode: the form is working, but registrations are not being saved yet. Configure Supabase in config.js before publishing.';
      statusEl.classList.add('error');
    }
  } catch (error) {
    statusEl.textContent = 'Could not submit right now. Please call 9509767993 or email thegoodlistener2006@gmail.com. (' + error.message + ')';
    statusEl.classList.add('error');
  } finally {
    submit.disabled = false;
    submit.innerHTML = 'SUBMIT REGISTRATION <span>↗</span>';
  }
});
