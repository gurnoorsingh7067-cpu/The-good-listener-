// The Good Listener configuration
// Paste your Supabase PROJECT URL and publishable/anon key below.
// Never put a Supabase service_role key in this public website.
window.TGL_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
